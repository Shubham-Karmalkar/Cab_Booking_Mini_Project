package com.example.cabProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CabProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
