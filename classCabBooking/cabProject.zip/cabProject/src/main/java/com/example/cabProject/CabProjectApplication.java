package com.example.cabProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CabProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(CabProjectApplication.class, args);
	}

}
